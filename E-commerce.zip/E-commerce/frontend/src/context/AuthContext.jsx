import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../services/api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
	const [user, setUser] = useState(() => {
		const stored = localStorage.getItem("sg_user");
		return stored ? JSON.parse(stored) : null;
	});
	const [token, setToken] = useState(() => localStorage.getItem("sg_token"));

	useEffect(() => {
		if (user) localStorage.setItem("sg_user", JSON.stringify(user));
		else localStorage.removeItem("sg_user");
	}, [user]);

	useEffect(() => {
		if (token) localStorage.setItem("sg_token", token);
		else localStorage.removeItem("sg_token");
	}, [token]);

	const requestOtp = async (phone) => {
		await api.post("/users/request-otp", { phone });
	};

	const verifyOtp = async (phone, otp) => {
		const res = await api.post("/users/verify-otp", { phone, otp });
		setToken(res.data.token);
		setUser(res.data.user);
	};

	const updateProfile = async (profile) => {
		const res = await api.put("/users/profile", profile);
		setUser(res.data.user);
	};

	const logout = () => {
		setToken(null);
		setUser(null);
	};

	return (
		<AuthContext.Provider value={{ user, token, requestOtp, verifyOtp, updateProfile, logout }}>
			{children}
		</AuthContext.Provider>
	);
}

export function useAuth() {
	return useContext(AuthContext);
}


