import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiWithAuth } from "../services/api.js";
import { useAuth } from "./AuthContext.jsx";

const CartContext = createContext(null);

export function CartProvider({ children }) {
	const { token } = useAuth();
	const [cart, setCart] = useState({ items: [] });

	useEffect(() => {
		if (!token) {
			setCart({ items: [] });
			return;
		}
		(async () => {
			const api = apiWithAuth(token);
			const res = await api.get("/cart");
			setCart(res.data.cart);
		})();
	}, [token]);

	const addOrUpdateItem = async (productId, quantity) => {
		if (!token) {
			return { error: "Login required" };
		}
		const api = apiWithAuth(token);
		const res = await api.post("/cart/items", { productId, quantity });
		setCart(res.data.cart);
	};

	const removeItem = async (productId) => {
		if (!token) return;
		const api = apiWithAuth(token);
		const res = await api.delete(`/cart/items/${productId}`);
		setCart(res.data.cart);
	};

	const clearCart = async () => {
		if (!token) return;
		const api = apiWithAuth(token);
		await api.delete("/cart");
		setCart({ items: [] });
	};

	const totals = useMemo(() => {
		const subtotal = (cart.items || []).reduce((sum, i) => {
			const price = i.product?.price ?? 0;
			const discount = i.product?.discount ?? 0;
			const discounted = price * (1 - discount / 100);
			return sum + discounted * i.quantity;
		}, 0);
		return { subtotal: Math.round(subtotal * 100) / 100 };
	}, [cart]);

	return (
		<CartContext.Provider value={{ cart, setCart, addOrUpdateItem, removeItem, clearCart, totals }}>
			{children}
		</CartContext.Provider>
	);
}

export function useCart() {
	return useContext(CartContext);
}


