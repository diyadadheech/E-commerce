import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useCart } from "../context/CartContext.jsx";
import { apiWithAuth } from "../services/api.js";

export default function CheckoutPage() {
	const { token, user } = useAuth();
	const { totals, setCart } = useCart();
	const navigate = useNavigate();

	const placeOrder = async () => {
		const api = apiWithAuth(token);
		const res = await api.post("/orders");
		setCart({ items: [] });
		alert("Order placed successfully!");
		navigate("/");
	};

	if (!token) {
		return <div>Please login to continue.</div>;
	}

	return (
		<div className="max-w-xl mx-auto space-y-4">
			<h2 className="text-2xl font-bold">Checkout</h2>
			<div className="p-4 bg-white border rounded-xl">
				<h3 className="font-semibold">Delivery Address</h3>
				<p className="text-gray-700 mt-1 whitespace-pre-line">{user?.address || "No address set"}</p>
			</div>
			<div className="p-4 bg-white border rounded-xl">
				<div className="flex justify-between">
					<span>Total Payable</span>
					<span className="font-semibold">₹{totals.subtotal.toFixed(2)}</span>
				</div>
				<button onClick={placeOrder} className="mt-4 w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
					Place Order
				</button>
			</div>
		</div>
	);
}


