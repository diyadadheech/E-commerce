import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api.js";
import ProductCard from "../components/ProductCard.jsx";

export default function CategoryPage() {
	const { categoryName } = useParams();
	const [products, setProducts] = useState([]);
	const [sort, setSort] = useState("price");
	const [order, setOrder] = useState("asc");
	const [minPrice, setMinPrice] = useState("");
	const [maxPrice, setMaxPrice] = useState("");
	const encoded = useMemo(() => encodeURIComponent(categoryName), [categoryName]);

	useEffect(() => {
		(async () => {
			const res = await api.get(`/products?category=${encoded}&sort=${sort}&order=${order}` + 
				(minPrice ? `&minPrice=${minPrice}` : "") + (maxPrice ? `&maxPrice=${maxPrice}` : ""));
			setProducts(res.data.products);
		})();
	}, [encoded, sort, order, minPrice, maxPrice]);

	return (
		<div className="space-y-4">
			<h2 className="text-2xl font-bold">{categoryName}</h2>
			<div className="flex flex-wrap items-end gap-3">
				<div>
					<label className="block text-sm text-gray-600">Sort by</label>
					<select value={sort} onChange={(e) => setSort(e.target.value)} className="border rounded-md px-3 py-2">
						<option value="price">Price</option>
						<option value="discount">Discount</option>
					</select>
				</div>
				<div>
					<label className="block text-sm text-gray-600">Order</label>
					<select value={order} onChange={(e) => setOrder(e.target.value)} className="border rounded-md px-3 py-2">
						<option value="asc">Asc</option>
						<option value="desc">Desc</option>
					</select>
				</div>
				<div>
					<label className="block text-sm text-gray-600">Min Price</label>
					<input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="border rounded-md px-3 py-2 w-28" />
				</div>
				<div>
					<label className="block text-sm text-gray-600">Max Price</label>
					<input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="border rounded-md px-3 py-2 w-28" />
				</div>
			</div>
			<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
				{products.map((p) => (
					<ProductCard key={p._id} product={p} />
				))}
			</div>
		</div>
	);
}


