import { useState } from "react";
import { useAuth } from "../../context/AuthContext.jsx";

export default function LoginModal() {
	const [step, setStep] = useState(1);
	const [phone, setPhone] = useState("");
	const [otp, setOtp] = useState("");
	const [name, setName] = useState("");
	const [email, setEmail] = useState("");
	const [address, setAddress] = useState("");
	const [loading, setLoading] = useState(false);
	const { requestOtp, verifyOtp, updateProfile, user } = useAuth();

	const onRequestOtp = async () => {
		if (!phone) return;
		setLoading(true);
		await requestOtp(phone);
		setLoading(false);
		setStep(2);
	};

	const onVerify = async () => {
		setLoading(true);
		await verifyOtp(phone, otp);
		setLoading(false);
		setStep(3);
	};

	const onSaveProfile = async () => {
		setLoading(true);
		await updateProfile({ phone, name, email, address });
		setLoading(false);
		document.getElementById("login-modal")?.close();
	};

	return (
		<dialog id="login-modal" className="modal">
			<div className="modal-box max-w-md">
				<form method="dialog">
					<button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
				</form>
				<h3 className="font-bold text-lg mb-4">Login with Phone</h3>
				{step === 1 && (
					<div className="space-y-3">
						<input value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full border rounded-md px-3 py-2" placeholder="Phone number" />
						<button disabled={loading} onClick={onRequestOtp} className="w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
							{loading ? "Sending..." : "Send OTP"}
						</button>
						<p className="text-xs text-gray-500">OTP is simulated and shown in backend console.</p>
					</div>
				)}
				{step === 2 && (
					<div className="space-y-3">
						<input value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full border rounded-md px-3 py-2" placeholder="Enter OTP" />
						<button disabled={loading} onClick={onVerify} className="w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
							{loading ? "Verifying..." : "Verify OTP"}
						</button>
					</div>
				)}
				{step === 3 && (
					<div className="space-y-3">
						<input value={name} onChange={(e) => setName(e.target.value)} className="w-full border rounded-md px-3 py-2" placeholder="Full name" />
						<input value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border rounded-md px-3 py-2" placeholder="Email" />
						<textarea value={address} onChange={(e) => setAddress(e.target.value)} className="w-full border rounded-md px-3 py-2" placeholder="Delivery address"></textarea>
						<button disabled={loading} onClick={onSaveProfile} className="w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
							{loading ? "Saving..." : "Save & Continue"}
						</button>
					</div>
				)}
			</div>
		</dialog>
	);
}


