import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function CartPage() {
	const { cart, addOrUpdateItem, removeItem, totals } = useCart();
	const { token } = useAuth();
	const navigate = useNavigate();
	const items = cart.items || [];
	return (
		<div className="grid md:grid-cols-3 gap-6">
			<div className="md:col-span-2 space-y-4">
				<h2 className="text-2xl font-bold">Your Cart</h2>
				{items.length === 0 ? (
					<div className="p-6 bg-white border rounded-xl">
						Your cart is empty. <Link to="/" className="text-green-700 underline">Browse products</Link>
					</div>
				) : (
					items.map((i) => (
						<div key={i.product._id} className="p-4 bg-white border rounded-xl flex items-center gap-4">
							<div className="w-20 h-20 bg-gray-50 rounded-md flex items-center justify-center">
								{i.product.image ? <img src={i.product.image} className="w-full h-full object-cover rounded-md" /> : <span className="text-gray-400">No Image</span>}
							</div>
							<div className="flex-1">
								<div className="font-medium">{i.product.name}</div>
								<div className="text-sm text-gray-500">{i.product.category}</div>
								<div className="mt-2 flex items-center gap-2">
									<input
										type="number"
										min={1}
										value={i.quantity}
										onChange={(e) => addOrUpdateItem(i.product._id, Number(e.target.value))}
										className="w-20 border rounded-md px-2 py-1"
									/>
									<button onClick={() => removeItem(i.product._id)} className="text-red-600 hover:underline">
										Remove
									</button>
								</div>
							</div>
						</div>
					))
				)}
			</div>
			<div className="space-y-4">
				<div className="p-4 bg-white border rounded-xl">
					<h3 className="font-semibold mb-2">Summary</h3>
					<div className="flex justify-between">
						<span>Subtotal</span>
						<span>₹{totals.subtotal.toFixed(2)}</span>
					</div>
					<button
						onClick={() => {
							if (!token) { document.getElementById("login-modal")?.showModal(); return; }
							navigate("/checkout");
						}}
						className="mt-4 w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
					>
						Buy Now
					</button>
				</div>
			</div>
		</div>
	);
}


