import CategoryGrid from "../components/CategoryGrid.jsx";
import LoginModal from "./components/LoginModal.jsx";

export default function HomePage() {
	return (
		<div className="space-y-6">
			<section className="text-center py-8 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl">
				<h1 className="text-3xl sm:text-4xl font-bold">Your Daily Groceries, Delivered Fresh</h1>
				<p className="mt-2 text-gray-600">Browse categories below and add items to your cart.</p>
			</section>
			<CategoryGrid />
			<LoginModal />
		</div>
	);
}


