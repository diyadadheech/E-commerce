import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api.js";
import { useCart } from "../context/CartContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function ProductDetailPage() {
	const { productId } = useParams();
	const [product, setProduct] = useState(null);
	const [qty, setQty] = useState(1);
	const { addOrUpdateItem } = useCart();
	const { token } = useAuth();

	useEffect(() => {
		(async () => {
			const res = await api.get(`/products/${productId}`);
			setProduct(res.data.product);
		})();
	}, [productId]);

	if (!product) return <div>Loading...</div>;
	const discounted = product.price * (1 - (product.discount || 0) / 100);

	return (
		<div className="grid md:grid-cols-2 gap-6">
			<div className="bg-gray-50 rounded-xl aspect-square flex items-center justify-center">
				{product.imageUrl ? (
					<img src={product.imageUrl} alt={product.name} className="object-cover w-full h-full rounded-xl" />
				) : (
					<span className="text-gray-400">No Image</span>
				)}
			</div>
			<div>
				<h1 className="text-2xl font-bold">{product.name}</h1>
				<div className="mt-2 text-gray-600">{product.category}</div>
				{product.brand ? <div className="mt-1 text-sm text-gray-500">Brand: {product.brand}</div> : null}
				<div className="mt-4 flex items-center gap-3">
					<div className="text-3xl font-semibold">₹{discounted.toFixed(2)}</div>
					{product.discount ? (
						<>
							<div className="text-gray-400 line-through">₹{product.price.toFixed(2)}</div>
							<div className="text-green-600 font-medium">-{product.discount}%</div>
						</>
					) : null}
				</div>
				{product.expiryDate ? <div className="mt-2 text-sm text-gray-600">Expiry: {product.expiryDate}</div> : null}
				<p className="mt-4 text-gray-700">{product.description}</p>
				<div className="mt-6 flex items-center gap-3">
					<input
						type="number"
						min={1}
						value={qty}
						onChange={(e) => setQty(Number(e.target.value))}
						className="w-20 border rounded-md px-3 py-2"
					/>
					<button
						onClick={() => {
							if (!token) { document.getElementById("login-modal")?.showModal(); return; }
							addOrUpdateItem(product._id, qty);
						}}
						className="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
					>
						Add to Cart
					</button>
				</div>
			</div>
		</div>
	);
}


