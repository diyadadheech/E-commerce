import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import HomePage from "./pages/HomePage.jsx";
import CategoryPage from "./pages/CategoryPage.jsx";
import ProductDetailPage from "./pages/ProductDetailPage.jsx";
import CartPage from "./pages/CartPage.jsx";
import CheckoutPage from "./pages/CheckoutPage.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { CartProvider } from "./context/CartContext.jsx";

export default function App() {
	return (
		<AuthProvider>
			<CartProvider>
				<div className="min-h-screen flex flex-col">
					<Navbar />
					<main className="flex-1 container-responsive py-6">
						<Routes>
							<Route path="/" element={<HomePage />} />
							<Route path="/category/:categoryName" element={<CategoryPage />} />
							<Route path="/product/:productId" element={<ProductDetailPage />} />
							<Route path="/cart" element={<CartPage />} />
							<Route path="/checkout" element={<CheckoutPage />} />
						</Routes>
					</main>
				</div>
			</CartProvider>
		</AuthProvider>
	);
}


