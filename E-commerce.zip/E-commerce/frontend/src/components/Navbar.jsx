import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar() {
	const { cart } = useCart();
	const { user, logout } = useAuth();
	const navigate = useNavigate();
	const count = (cart.items || []).reduce((sum, i) => sum + i.quantity, 0);
	return (
		<header className="bg-white border-b">
			<div className="container-responsive py-4 flex items-center justify-between">
				<Link to="/" className="text-2xl font-bold">SmartGrocery</Link>
				<nav className="flex items-center gap-4">
					<Link to="/cart" className="relative inline-flex items-center">
						<span className="material-icons mr-1">shopping_cart</span>
						Cart
						{count > 0 && (
							<span className="ml-2 inline-flex items-center justify-center text-xs bg-green-600 text-white rounded-full w-5 h-5">
								{count}
							</span>
						)}
					</Link>
					{user ? (
						<button onClick={() => { logout(); navigate("/"); }} className="px-3 py-1 rounded-md bg-gray-100 hover:bg-gray-200">
							Logout
						</button>
					) : (
						<a href="#login" onClick={() => document.getElementById("login-modal")?.showModal()} className="px-3 py-1 rounded-md bg-green-600 text-white hover:bg-green-700">
							Login
						</a>
					)}
				</nav>
			</div>
		</header>
	);
}


