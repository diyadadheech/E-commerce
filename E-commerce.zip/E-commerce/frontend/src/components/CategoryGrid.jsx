import { Link } from "react-router-dom";

const categories = [
	{ label: "Milk, Curd & Dairy", emoji: "🥛" },
	{ label: "Vegetables & Fruits", emoji: "🥦" },
	{ label: "Cakes & Biscuits", emoji: "🍰" },
	{ label: "Aata, Rice & Dal", emoji: "🌾" },
	{ label: "Oil, Ghee & Masala", emoji: "🧂" },
	{ label: "Dry Fruits", emoji: "🥜" },
	{ label: "Bakery", emoji: "🍞" },
	{ label: "Drinks", emoji: "🥤" },
	{ label: "Chocolates", emoji: "🍫" },
];

export default function CategoryGrid() {
	return (
		<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
			{categories.map((c) => (
				<Link
					key={c.label}
					to={`/category/${encodeURIComponent(c.label)}`}
					className="group border rounded-xl p-4 flex flex-col items-center justify-center hover:shadow-md transition-shadow bg-white"
				>
					<div className="text-4xl mb-2">{c.emoji}</div>
					<div className="font-medium text-center">{c.label}</div>
				</Link>
			))}
		</div>
	);
}


