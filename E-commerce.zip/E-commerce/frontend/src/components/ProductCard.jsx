import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function ProductCard({ product }) {
	const { addOrUpdateItem } = useCart();
	const { token } = useAuth();
	const discounted = product.price * (1 - (product.discount || 0) / 100);
	return (
		<div className="border rounded-xl overflow-hidden bg-white hover:shadow-md transition-shadow">
			<Link to={`/product/${product._id}`} className="block">
				<div className="aspect-square bg-gray-50 flex items-center justify-center">
					{product.imageUrl ? (
						<img src={product.imageUrl} alt={product.name} className="object-cover w-full h-full" />
					) : (
						<span className="text-gray-400">No Image</span>
					)}
				</div>
				<div className="p-3">
					<div className="font-medium line-clamp-1">{product.name}</div>
					<div className="mt-1 text-sm text-gray-500">{product.category}</div>
					<div className="mt-2 flex items-center gap-2">
						<div className="text-lg font-semibold">₹{discounted.toFixed(2)}</div>
						{product.discount ? (
							<>
								<div className="text-gray-400 line-through text-sm">₹{product.price.toFixed(2)}</div>
								<div className="text-green-600 text-sm font-medium">-{product.discount}%</div>
							</>
						) : null}
					</div>
				</div>
			</Link>
			<div className="p-3">
				<button
					onClick={() => {
						if (!token) {
							document.getElementById("login-modal")?.showModal();
							return;
						}
						addOrUpdateItem(product._id, 1);
					}}
					className="w-full py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
				>
					Add to Cart
				</button>
			</div>
		</div>
	);
}


