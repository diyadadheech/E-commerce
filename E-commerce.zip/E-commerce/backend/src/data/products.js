const img = (u) => `${u}?auto=format&fit=crop&w=800&q=60`;

const products = [
	// Milk, Curd & Dairy
	{ name: "Amul Taaza Milk 1L", brand: "Amul", category: "Milk, Curd & Dairy", price: 65, discount: 10, expiryDate: "2025-12-10", description: "Fresh Amul Taaza milk packed with essential nutrients and vitamins.", imageUrl: img("https://images.unsplash.com/photo-1582719478250-c89cae4dc85b") },
	{ name: "Mother Dairy Curd 400g", brand: "Mother Dairy", category: "Milk, Curd & Dairy", price: 45, discount: 5, expiryDate: "2025-11-15", description: "Creamy and delicious curd from Mother Dairy.", imageUrl: img("https://images.unsplash.com/photo-1563630423918-df5d1b1e168e") },
	{ name: "Amul Butter 100g", brand: "Amul", category: "Milk, Curd & Dairy", price: 52, discount: 8, expiryDate: "2026-02-20", description: "Classic salted butter for everyday cooking and baking.", imageUrl: img("https://images.unsplash.com/photo-1505575972945-290b8cc1d0d1") },
	{ name: "Nestle Milkmaid 400g", brand: "Nestle", category: "Milk, Curd & Dairy", price: 135, discount: 12, expiryDate: "2026-06-18", description: "Sweetened condensed milk, perfect for desserts.", imageUrl: img("https://images.unsplash.com/photo-1542831371-29b0f74f9713") },
	{ name: "Amul Cheese Slices 200g", brand: "Amul", category: "Milk, Curd & Dairy", price: 120, discount: 10, expiryDate: "2026-03-10", description: "Rich and creamy cheese slices.", imageUrl: img("https://images.unsplash.com/photo-1604908176997-4313392bca7a") },
	{ name: "Yakult Probiotic Drink (5 x 65ml)", brand: "Yakult", category: "Milk, Curd & Dairy", price: 85, discount: 5, expiryDate: "2025-12-25", description: "Probiotic fermented milk drink for digestive health.", imageUrl: img("https://images.unsplash.com/photo-1579702493448-1c2f56a3933e") },

	// Vegetables & Fruits
	{ name: "Fresh Tomatoes 1kg", brand: "Farm Fresh", category: "Vegetables & Fruits", price: 40, discount: 10, expiryDate: "2025-11-20", description: "Juicy red tomatoes ideal for salads and cooking.", imageUrl: img("https://images.unsplash.com/photo-1546470427-e842ea9c8eeb") },
	{ name: "Bananas 1 Dozen", brand: "Farm Fresh", category: "Vegetables & Fruits", price: 60, discount: 5, expiryDate: "2025-11-12", description: "Ripe and sweet bananas.", imageUrl: img("https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e") },
	{ name: "Red Apples 1kg", brand: "Kashmir Orchards", category: "Vegetables & Fruits", price: 150, discount: 12, expiryDate: "2025-12-05", description: "Crisp and fresh apples from the valley.", imageUrl: img("https://images.unsplash.com/photo-1567306226416-28f0efdc88ce") },
	{ name: "Baby Spinach 250g", brand: "Leafy Greens", category: "Vegetables & Fruits", price: 40, discount: 8, expiryDate: "2025-11-08", description: "Tender baby spinach leaves.", imageUrl: img("https://images.unsplash.com/photo-1540420773420-3366772f4999") },
	{ name: "Carrots 1kg", brand: "Farm Fresh", category: "Vegetables & Fruits", price: 45, discount: 10, expiryDate: "2025-11-18", description: "Crunchy and sweet carrots.", imageUrl: img("https://images.unsplash.com/photo-1547514701-9cdcb1f5941c") },
	{ name: "Oranges 1kg", brand: "Nagpur Citrus", category: "Vegetables & Fruits", price: 90, discount: 7, expiryDate: "2025-12-12", description: "Fresh and juicy oranges rich in Vitamin C.", imageUrl: img("https://images.unsplash.com/photo-1547517023-7ca0c162f816") },

	// Cakes & Biscuits
	{ name: "Parle-G Biscuits 800g", brand: "Parle", category: "Cakes & Biscuits", price: 90, discount: 10, expiryDate: "2026-01-30", description: "Classic glucose biscuits loved across generations.", imageUrl: img("https://images.unsplash.com/photo-1509440159596-0249088772ff") },
	{ name: "Oreo Original 120g", brand: "Mondelez", category: "Cakes & Biscuits", price: 35, discount: 5, expiryDate: "2026-03-22", description: "Chocolate cookies with vanilla creme.", imageUrl: img("https://images.unsplash.com/photo-1590080875852-0c9576fa4290") },
	{ name: "Britannia Good Day 200g", brand: "Britannia", category: "Cakes & Biscuits", price: 45, discount: 8, expiryDate: "2026-02-11", description: "Cashew-rich crunchy biscuits.", imageUrl: img("https://images.unsplash.com/photo-1488477181946-6428a0291777") },
	{ name: "Chocolate Muffins (Pack of 4)", brand: "Bakehouse", category: "Cakes & Biscuits", price: 120, discount: 12, expiryDate: "2025-12-01", description: "Soft and moist chocolate muffins.", imageUrl: img("https://images.unsplash.com/photo-1606313564200-e75d5e30476f") },
	{ name: "Rusk 300g", brand: "Britannia", category: "Cakes & Biscuits", price: 55, discount: 10, expiryDate: "2026-02-15", description: "Crispy tea-time rusks.", imageUrl: img("https://images.unsplash.com/photo-1509440179594-7f3e0d9c282e") },
	{ name: "Marie Gold 250g", brand: "Britannia", category: "Cakes & Biscuits", price: 40, discount: 6, expiryDate: "2026-03-05", description: "Light tea-time biscuits.", imageUrl: img("https://images.unsplash.com/photo-1519681393784-d120267933ba") },

	// Aata, Rice & Dal
	{ name: "Aashirvaad Atta 5kg", brand: "Aashirvaad", category: "Aata, Rice & Dal", price: 265, discount: 10, expiryDate: "2026-05-01", description: "Whole wheat flour for soft rotis.", imageUrl: img("https://images.unsplash.com/photo-1563630423918-df5d1b1e168e") },
	{ name: "Basmati Rice 5kg", brand: "Daawat", category: "Aata, Rice & Dal", price: 599, discount: 15, expiryDate: "2027-01-01", description: "Aromatic long-grain basmati rice.", imageUrl: img("https://images.unsplash.com/photo-1604908177331-cfb1a0a0c3d7") },
	{ name: "Toor Dal 1kg", brand: "Tata Sampann", category: "Aata, Rice & Dal", price: 140, discount: 8, expiryDate: "2026-09-14", description: "Protein-rich toor dal.", imageUrl: img("https://images.unsplash.com/photo-1604908177519-8f8a9f65c1dc") },
	{ name: "Moong Dal 1kg", brand: "24 Mantra", category: "Aata, Rice & Dal", price: 130, discount: 10, expiryDate: "2026-08-20", description: "Organic moong dal.", imageUrl: img("https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2") },
	{ name: "Masoor Dal 1kg", brand: "Tata Sampann", category: "Aata, Rice & Dal", price: 120, discount: 9, expiryDate: "2026-07-12", description: "Red lentils for quick meals.", imageUrl: img("https://images.unsplash.com/photo-1615486364693-ea51bd8a9a2a") },
	{ name: "Sona Masoori Rice 5kg", brand: "Fortune", category: "Aata, Rice & Dal", price: 429, discount: 12, expiryDate: "2027-02-10", description: "Light and fluffy everyday rice.", imageUrl: img("https://images.unsplash.com/photo-1552422535-c45813c61732") },

	// Oil, Ghee & Masala
	{ name: "Fortune Sunflower Oil 1L", brand: "Fortune", category: "Oil, Ghee & Masala", price: 150, discount: 10, expiryDate: "2026-11-11", description: "Refined sunflower oil.", imageUrl: img("https://images.unsplash.com/photo-1505575967455-40e256f73376") },
	{ name: "Amul Ghee 1L", brand: "Amul", category: "Oil, Ghee & Masala", price: 550, discount: 8, expiryDate: "2027-01-15", description: "Pure cow ghee.", imageUrl: img("https://images.unsplash.com/photo-1526318472351-c75fcf070305") },
	{ name: "MDH Garam Masala 100g", brand: "MDH", category: "Oil, Ghee & Masala", price: 75, discount: 5, expiryDate: "2026-10-20", description: "Aromatic garam masala blend.", imageUrl: img("https://images.unsplash.com/photo-1526312426976-593c2e615691") },
	{ name: "Everest Red Chilli Powder 200g", brand: "Everest", category: "Oil, Ghee & Masala", price: 120, discount: 10, expiryDate: "2026-12-12", description: "Hot and vibrant chilli powder.", imageUrl: img("https://images.unsplash.com/photo-1546527868-ccb7ee7dfa6a") },
	{ name: "Turmeric Powder 200g", brand: "Catch", category: "Oil, Ghee & Masala", price: 110, discount: 9, expiryDate: "2026-12-01", description: "Pure turmeric powder.", imageUrl: img("https://images.unsplash.com/photo-1628472934039-58f35b706b6a") },
	{ name: "Olive Oil Extra Virgin 500ml", brand: "Figaro", category: "Oil, Ghee & Masala", price: 650, discount: 15, expiryDate: "2027-03-22", description: "Premium extra virgin olive oil.", imageUrl: img("https://images.unsplash.com/photo-1505577058444-a3dab90d4253") },

	// Dry Fruits
	{ name: "Almonds 500g", brand: "Nutty", category: "Dry Fruits", price: 450, discount: 12, expiryDate: "2026-12-30", description: "Premium California almonds.", imageUrl: img("https://images.unsplash.com/photo-1604908554348-9eacb28f0b66") },
	{ name: "Cashews 500g", brand: "Nutty", category: "Dry Fruits", price: 520, discount: 10, expiryDate: "2026-12-25", description: "Whole cashew nuts.", imageUrl: img("https://images.unsplash.com/photo-1587049352847-4c34b9eb97b5") },
	{ name: "Raisins 500g", brand: "Nutty", category: "Dry Fruits", price: 220, discount: 8, expiryDate: "2026-11-11", description: "Seedless golden raisins.", imageUrl: img("https://images.unsplash.com/photo-1590595906931-81a6f29ab5c0") },
	{ name: "Walnuts 500g", brand: "Nutty", category: "Dry Fruits", price: 580, discount: 10, expiryDate: "2026-12-01", description: "Shelled walnut kernels.", imageUrl: img("https://images.unsplash.com/photo-1547516508-4e7ab1c9a09b") },
	{ name: "Pistachios 500g", brand: "Nutty", category: "Dry Fruits", price: 650, discount: 12, expiryDate: "2026-12-15", description: "Roasted and salted pistachios.", imageUrl: img("https://images.unsplash.com/photo-1515542706656-8e6ef17a1521") },
	{ name: "Dried Figs 250g", brand: "Nutty", category: "Dry Fruits", price: 320, discount: 9, expiryDate: "2026-10-18", description: "Soft and sweet figs.", imageUrl: img("https://images.unsplash.com/photo-1459411552884-841db9b3cc2a") },

	// Bakery
	{ name: "Whole Wheat Bread 400g", brand: "Bakehouse", category: "Bakery", price: 45, discount: 5, expiryDate: "2025-11-07", description: "Soft and fresh whole wheat bread.", imageUrl: img("https://images.unsplash.com/photo-1549931319-a545dcf3bc73") },
	{ name: "Garlic Bread 200g", brand: "Bakehouse", category: "Bakery", price: 80, discount: 8, expiryDate: "2025-11-10", description: "Buttery garlic bread.", imageUrl: img("https://images.unsplash.com/photo-1541780853-1b1b78a82a33") },
	{ name: "Croissants (Pack of 2)", brand: "Bakehouse", category: "Bakery", price: 110, discount: 10, expiryDate: "2025-11-06", description: "Flaky French croissants.", imageUrl: img("https://images.unsplash.com/photo-1512058564366-18510be2db19") },
	{ name: "Multigrain Bread 400g", brand: "Bakehouse", category: "Bakery", price: 55, discount: 6, expiryDate: "2025-11-08", description: "Healthy multigrain loaf.", imageUrl: img("https://images.unsplash.com/photo-1608198093002-ad4e005484ec") },
	{ name: "Chocolate Donuts (Pack of 3)", brand: "Bakehouse", category: "Bakery", price: 150, discount: 12, expiryDate: "2025-11-05", description: "Soft donuts with chocolate glaze.", imageUrl: img("https://images.unsplash.com/photo-1495147466023-ac5c588e2e94") },
	{ name: "Pita Bread 6pcs", brand: "Bakehouse", category: "Bakery", price: 85, discount: 7, expiryDate: "2025-11-09", description: "Fresh pita pockets.", imageUrl: img("https://images.unsplash.com/photo-1542838132-92c53300491e") },

	// Drinks
	{ name: "Coca-Cola 2L", brand: "Coca-Cola", category: "Drinks", price: 95, discount: 5, expiryDate: "2026-04-10", description: "Classic coke.", imageUrl: img("https://images.unsplash.com/photo-1541976076758-347942db1970") },
	{ name: "Pepsi 2L", brand: "Pepsi", category: "Drinks", price: 90, discount: 6, expiryDate: "2026-04-12", description: "Refreshing Pepsi.", imageUrl: img("https://images.unsplash.com/photo-1542992015-4a0b729b1385") },
	{ name: "Tropicana Orange 1L", brand: "Tropicana", category: "Drinks", price: 120, discount: 10, expiryDate: "2026-02-18", description: "Orange juice beverage.", imageUrl: img("https://images.unsplash.com/photo-1556679343-c7306c2b42f1") },
	{ name: "Red Bull 250ml", brand: "Red Bull", category: "Drinks", price: 110, discount: 5, expiryDate: "2026-06-01", description: "Energy drink.", imageUrl: img("https://images.unsplash.com/photo-1603354350317-1d21f7a6e79a") },
	{ name: "Bisleri Water 2L", brand: "Bisleri", category: "Drinks", price: 35, discount: 0, expiryDate: "2027-01-01", description: "Packaged drinking water.", imageUrl: img("https://images.unsplash.com/photo-1526045612212-70caf35c14df") },
	{ name: "Sprite 2L", brand: "Coca-Cola", category: "Drinks", price: 90, discount: 6, expiryDate: "2026-04-15", description: "Lemon-lime soda.", imageUrl: img("https://images.unsplash.com/photo-1623726428608-6d53295d85f1") },

	// Chocolates
	{ name: "Cadbury Dairy Milk 150g", brand: "Cadbury", category: "Chocolates", price: 120, discount: 10, expiryDate: "2026-05-05", description: "Smooth and creamy milk chocolate.", imageUrl: img("https://images.unsplash.com/photo-1624359136353-4c0a5bb5294a") },
	{ name: "KitKat 4 Finger 37g", brand: "Nestle", category: "Chocolates", price: 30, discount: 5, expiryDate: "2026-06-02", description: "Crispy wafer fingers covered with chocolate.", imageUrl: img("https://images.unsplash.com/photo-1589712186622-48b3b0b5c8f5") },
	{ name: "Snickers 50g", brand: "Mars", category: "Chocolates", price: 45, discount: 6, expiryDate: "2026-07-12", description: "Chocolate bar with peanuts and caramel.", imageUrl: img("https://images.unsplash.com/photo-1621684414889-8cbbf6b25143") },
	{ name: "Ferrero Rocher 200g", brand: "Ferrero", category: "Chocolates", price: 599, discount: 12, expiryDate: "2026-12-12", description: "Hazelnut chocolates.", imageUrl: img("https://images.unsplash.com/photo-1612208695882-2c30f082e135") },
	{ name: "Bounty 57g", brand: "Mars", category: "Chocolates", price: 50, discount: 6, expiryDate: "2026-08-20", description: "Coconut filled bar.", imageUrl: img("https://images.unsplash.com/photo-1606313562879-9c514f85a3b4") },
	{ name: "Dark Chocolate 70% 100g", brand: "Lindt", category: "Chocolates", price: 250, discount: 10, expiryDate: "2026-10-01", description: "Rich dark chocolate bar.", imageUrl: img("https://images.unsplash.com/photo-1598899134739-24b4b2d6f96f") },
];

export default products;


