import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import { connectToDatabase } from "./lib/db.js";
import usersRouter from "./routes/users.js";
import productsRouter from "./routes/products.js";
import cartRouter from "./routes/cart.js";
import ordersRouter from "./routes/orders.js";
import { seedProductsIfEmpty } from "./lib/seed.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;
const clientOrigin = process.env.CLIENT_ORIGIN || "http://localhost:5173";

app.use(cors({ origin: clientOrigin, credentials: true }));
app.use(express.json());
app.use(morgan("dev"));

app.get("/api/health", (_req, res) => {
	res.json({ status: "ok" });
});

app.use("/api/users", usersRouter);
app.use("/api/products", productsRouter);
app.use("/api/cart", cartRouter);
app.use("/api/orders", ordersRouter);

app.use((err, _req, res, _next) => {
	console.error(err);
	const status = err.status || 500;
	res.status(status).json({ error: err.message || "Internal Server Error" });
});

async function start() {
	await connectToDatabase(process.env.MONGO_URI);
	await seedProductsIfEmpty();
	app.listen(port, () => {
		console.log(`API listening on http://localhost:${port}`);
	});
}

start().catch((error) => {
	console.error("Failed to start server:", error);
	process.exit(1);
});


