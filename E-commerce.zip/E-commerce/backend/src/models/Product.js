import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
	{
		name: { type: String, required: true },
		brand: { type: String },
		category: {
			type: String,
			required: true,
			enum: [
				"Milk, Curd & Dairy",
				"Vegetables & Fruits",
				"Cakes & Biscuits",
				"Aata, Rice & Dal",
				"Oil, Ghee & Masala",
				"Dry Fruits",
				"Bakery",
				"Drinks",
				"Chocolates",
			],
		},
		price: { type: Number, required: true },
		discount: { type: Number, default: 0 },
		expiryDate: { type: String },
		imageUrl: { type: String },
		description: { type: String },
		inStock: { type: Boolean, default: true },
	},
	{ timestamps: true }
);

export default mongoose.model("Product", productSchema);


