import { Router } from "express";
import User from "../models/User.js";
import { generateOtp } from "../utils/otp.js";
import { signToken } from "../middleware/auth.js";

const router = Router();

// Request OTP (simulate)
router.post("/request-otp", async (req, res, next) => {
	try {
		const { phone } = req.body;
		if (!phone) return res.status(400).json({ error: "Phone is required" });
		let user = await User.findOne({ phone });
		if (!user) {
			user = await User.create({ phone, verified: false });
		}
		const otp = generateOtp();
		user.otp = otp;
		await user.save();
		console.log(`OTP for ${phone}: ${otp}`);
		res.json({ message: "OTP sent (simulated). Check server console." });
	} catch (err) {
		next(err);
	}
});

// Verify OTP and issue JWT
router.post("/verify-otp", async (req, res, next) => {
	try {
		const { phone, otp } = req.body;
		if (!phone || !otp) return res.status(400).json({ error: "Phone and OTP are required" });
		const user = await User.findOne({ phone });
		if (!user || user.otp !== otp) {
			return res.status(400).json({ error: "Invalid OTP" });
		}
		user.verified = true;
		user.otp = undefined;
		await user.save();
		const token = signToken(user.id);
		res.json({ token, user: { id: user.id, phone: user.phone, name: user.name, email: user.email, address: user.address, verified: user.verified } });
	} catch (err) {
		next(err);
	}
});

// Update profile
router.put("/profile", async (req, res, next) => {
	try {
		const { phone, name, email, address } = req.body;
		if (!phone) return res.status(400).json({ error: "Phone is required" });
		const user = await User.findOneAndUpdate(
			{ phone },
			{ $set: { name, email, address } },
			{ new: true }
		);
		if (!user) return res.status(404).json({ error: "User not found" });
		res.json({ user: { id: user.id, phone: user.phone, name: user.name, email: user.email, address: user.address, verified: user.verified } });
	} catch (err) {
		next(err);
	}
});

export default router;


