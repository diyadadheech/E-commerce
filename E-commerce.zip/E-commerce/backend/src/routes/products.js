import { Router } from "express";
import Product from "../models/Product.js";

const router = Router();

// GET /api/products?category=...&minPrice=&maxPrice=&sort=price|discount&order=asc|desc
router.get("/", async (req, res, next) => {
	try {
		const { category, minPrice, maxPrice, sort, order } = req.query;
		const filter = {};
		if (category) filter.category = category;
		if (minPrice || maxPrice) {
			filter.price = {};
			if (minPrice) filter.price.$gte = Number(minPrice);
			if (maxPrice) filter.price.$lte = Number(maxPrice);
		}
		let query = Product.find(filter);
		if (sort) {
			const sortField = sort === "discount" ? "discount" : "price";
			const sortOrder = order === "desc" ? -1 : 1;
			query = query.sort({ [sortField]: sortOrder });
		}
		const products = await query.exec();
		res.json({ products });
	} catch (err) {
		next(err);
	}
});

// GET by id
router.get("/:id", async (req, res, next) => {
	try {
		const product = await Product.findById(req.params.id);
		if (!product) return res.status(404).json({ error: "Product not found" });
		res.json({ product });
	} catch (err) {
		next(err);
	}
});

export default router;


