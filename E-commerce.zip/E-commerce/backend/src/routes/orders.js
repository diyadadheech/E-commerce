import { Router } from "express";
import Cart from "../models/Cart.js";
import Order from "../models/Order.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.use(requireAuth);

// Place order from current cart
router.post("/", async (req, res, next) => {
	try {
		const cart = await Cart.findOne({ userId: req.user.id }).populate("items.product");
		if (!cart || cart.items.length === 0) return res.status(400).json({ error: "Cart is empty" });
		const items = cart.items.map((i) => ({
			product: i.product._id,
			quantity: i.quantity,
			priceAtPurchase: i.product.price,
			discountAtPurchase: i.product.discount || 0,
		}));
		const totalAmount = items.reduce((sum, i) => {
			const discounted = i.priceAtPurchase * (1 - (i.discountAtPurchase || 0) / 100);
			return sum + discounted * i.quantity;
		}, 0);
		const order = await Order.create({
			userId: req.user.id,
			items,
			totalAmount: Math.round(totalAmount * 100) / 100,
		});
		cart.items = [];
		await cart.save();
		res.status(201).json({ order });
	} catch (err) {
		next(err);
	}
});

// Get user's orders
router.get("/", async (req, res, next) => {
	try {
		const orders = await Order.find({ userId: req.user.id }).sort({ createdAt: -1 });
		res.json({ orders });
	} catch (err) {
		next(err);
	}
});

export default router;


