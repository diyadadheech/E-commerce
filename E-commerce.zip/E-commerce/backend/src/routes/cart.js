import { Router } from "express";
import Cart from "../models/Cart.js";
import Product from "../models/Product.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

router.use(requireAuth);

// Get current user's cart
router.get("/", async (req, res, next) => {
	try {
		const cart = await Cart.findOne({ userId: req.user.id }).populate("items.product");
		res.json({ cart: cart || { userId: req.user.id, items: [] } });
	} catch (err) {
		next(err);
	}
});

// Add or update an item
router.post("/items", async (req, res, next) => {
	try {
		const { productId, quantity } = req.body;
		if (!productId || !quantity) return res.status(400).json({ error: "productId and quantity are required" });
		const product = await Product.findById(productId);
		if (!product) return res.status(404).json({ error: "Product not found" });
		let cart = await Cart.findOne({ userId: req.user.id });
		if (!cart) {
			cart = await Cart.create({ userId: req.user.id, items: [] });
		}
		const idx = cart.items.findIndex((i) => i.product.toString() === productId);
		if (idx >= 0) {
			cart.items[idx].quantity = quantity;
		} else {
			cart.items.push({ product: productId, quantity });
		}
		await cart.save();
		await cart.populate("items.product");
		res.json({ cart });
	} catch (err) {
		next(err);
	}
});

// Remove item
router.delete("/items/:productId", async (req, res, next) => {
	try {
		const { productId } = req.params;
		const cart = await Cart.findOne({ userId: req.user.id });
		if (!cart) return res.json({ cart: { userId: req.user.id, items: [] } });
		cart.items = cart.items.filter((i) => i.product.toString() !== productId);
		await cart.save();
		await cart.populate("items.product");
		res.json({ cart });
	} catch (err) {
		next(err);
	}
});

// Clear cart
router.delete("/", async (req, res, next) => {
	try {
		await Cart.findOneAndUpdate({ userId: req.user.id }, { items: [] }, { upsert: true });
		res.json({ success: true });
	} catch (err) {
		next(err);
	}
});

export default router;


